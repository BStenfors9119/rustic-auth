#!/bin/bash

if [ $# == "0" ]; then
        echo "Usage: `basename $0` -s <stackname> -t <template_file> [-p <parameter_file] [ -r aws_profile_name] [-g <tag list>]" >&2
        exit 1
fi

while getopts 's:t:p:r:g:' opt; do
        case $opt in
        s) stackname="$OPTARG"
        ;;
				t) template="file://$OPTARG"
				;;
				p) parameters="--parameters file://$OPTARG"
				;;
        r) aws_profile="--profile $OPTARG"
        ;;
        g) stack_tags="$OPTARG"
		;;
        \?) exit 1
        ;;
        esac
done

#Check if js is installed
which jq 1>/dev/null
if [ $? != 0 ]; then
        echo "Cant find jq in your path" >&2
        exit 1
fi

#If BUILD_NUMBER is not in env generate one for change-set-name
if [ -z $BUILD_NUMBER ]; then
	RANDOM=640
	BUILD_NUMBER="build-$RANDOM"
fi

if [ -z $stack_tags ]; then
	stack_tags="Key=ComponentTagsMissing,Value=true"
else
	stack_tags=`echo $stack_tags | tr ';' ' '`
fi

#Generat list of stacks
STACK_LIST=`aws cloudformation list-stacks $aws_profile --output json`
if [ $? != 0 ]; then
	echo "Cant get stack list, check your aws credentials or specify a profile" >&2
	exit 1
fi

#Look for stacks matching stack name that aren't DELETE_COMPLETE
EXISTING_STACKS=`echo $STACK_LIST | jq -r --arg stack $stackname '[.StackSummaries[] | select(.StackName == $stack and .StackStatus != "DELETE_COMPLETE")] | length'`

#If there is not an existing stack create one, else craeate a changeset and check it's number of changes
if [ $EXISTING_STACKS -eq  0 ]; then
	aws cloudformation create-stack --stack-name $stackname --template-body "$template" $parameters $aws_profile --capabilities "CAPABILITY_IAM" "CAPABILITY_NAMED_IAM" --tags $stack_tags >&2
	if [ $? != 0 ]; then
		echo "Error creating new stack $stackname" >&2
		exit 1
	fi
	aws cloudformation wait stack-create-complete --stack-name $stackname $aws_profile || exit 1
	echo "created"
else
	set -x
	CHANGESET=`aws cloudformation create-change-set --change-set-name jen$BUILD_NUMBER --stack-name $stackname $aws_profile --output json --template-body "$template" $parameters --capabilities "CAPABILITY_IAM" "CAPABILITY_NAMED_IAM" --tags $stack_tags`
	if [ $? != 0 ]; then
		echo "Error creting changeset for $stackname" >$2
		exit 1
	fi
	set +x
	CHANGEARN=`echo $CHANGESET | jq -r '.Id'`
	sleep 10
	CHANGE_INFO=`aws cloudformation describe-change-set $aws_profile --output json --change-set-name $CHANGEARN`

	# If the Changeset has no length the delete it
	if [ `echo $CHANGE_INFO | jq '.Changes | length'` == 0 ]; then
		aws cloudformation delete-change-set $aws_profile --change-set-name $CHANGEARN
		if [ $? != 0 ]; then
               		echo "Error deleting changeset $CHANGEARN" >$2
         		exit 1
		fi
		echo "Stack Exists and no changes are required" >&2
		echo "no changes"
		exit 0
	#If the Changeset has changes output the ARN
	elif [ `echo $CHANGE_INFO | jq '.Changes | length'` > 0 ]; then
		echo "$CHANGE_INFO" | \
		    python -c "import yaml, sys; print(yaml.dump(yaml.load(sys.stdin.read()), default_flow_style=False))" >&2
		echo "Change Required. Apply changeset ARN:" >&2
		echo $CHANGEARN
		exit 0
	#Else spit out the changeset if errors
	else
		echo "$CHANGE_INFO[@]" >&2
		exit 1
	fi
fi
