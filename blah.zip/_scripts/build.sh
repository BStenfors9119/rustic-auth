#!/usr/bin/env bash
docker build -t rustic-auth .