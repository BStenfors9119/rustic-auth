#!/usr/bin/env bash

export TOWER_WEB_TEMPLATE_DIR="./src/";

cargo run